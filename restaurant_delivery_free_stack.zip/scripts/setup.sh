#!/usr/bin/env bash
set -euo pipefail

# ---- settings ----
APP_DIR="restaurant_app"
FLUTTER_VERSION="stable"

echo "==> Working dir: $(pwd)"

# ---- install flutter (if missing) ----
if ! command -v flutter >/dev/null 2>&1; then
  echo "==> Flutter not found. Installing Flutter (stable) ..."
  if [ ! -d "$HOME/flutter" ]; then
    git clone https://github.com/flutter/flutter.git -b "$FLUTTER_VERSION" --depth 1 "$HOME/flutter"
  fi
  export PATH="$PATH:$HOME/flutter/bin"
fi

flutter --version
flutter config --enable-web >/dev/null 2>&1 || true

# ---- create flutter project if not exists ----
if [ ! -d "$APP_DIR" ]; then
  echo "==> Creating Flutter project: $APP_DIR"
  flutter create "$APP_DIR"
fi

echo "==> Copying scaffold code into $APP_DIR"
rsync -av --delete scaffold/lib/ "$APP_DIR/lib/"
rsync -av scaffold/pubspec.yaml "$APP_DIR/pubspec.yaml"
rsync -av scaffold/web/ "$APP_DIR/web/" || true
rsync -av scaffold/android/ "$APP_DIR/android/" || true

# google-services.json
if [ -f "scaffold/android/app/google-services.json" ]; then
  mkdir -p "$APP_DIR/android/app"
  cp "scaffold/android/app/google-services.json" "$APP_DIR/android/app/google-services.json"
fi

echo "==> Fetching packages"
( cd "$APP_DIR" && flutter pub get )

echo "==> Done."
echo ""
echo "Run web:"
echo "  cd $APP_DIR && flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8080"
echo ""
echo "Build apk:"
echo "  cd $APP_DIR && flutter build apk --release"
