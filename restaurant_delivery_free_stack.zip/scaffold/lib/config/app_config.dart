class AppConfig {
  // Supabase
  static const supabaseUrl = 'https://lntnirxxuoocvpjoarky.supabase.co';
  static const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxudG5pcnh4dW9vY3Zwam9hcmt5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyMjk2NTYsImV4cCI6MjA4MzgwNTY1Nn0.N6c61zww0V7zV9XF1KMhwywY6TjqJYQsJhsDiqrojMs';

  // Firebase Web (for web init)
  static const firebaseApiKey = 'AIzaSyDvNt9M9VqmZP_cDKokBgPhfteoE-F_bOA';
  static const firebaseAuthDomain = 'resdelivery-4b658.firebaseapp.com';
  static const firebaseProjectId = 'resdelivery-4b658';
  static const firebaseStorageBucket = 'resdelivery-4b658.firebasestorage.app';
  static const firebaseMessagingSenderId = '783938973684';
  static const firebaseAppId = '1:783938973684:web:3c58042bb9e8da304453a1';
  static const firebaseMeasurementId = 'G-QZC4YEKF9F';

  // FCM Web Push (VAPID)
  static const webVapidKey = 'BCTt6gFdmie7hI2pKD34FcD0dHd2S-FLE-SCozsm5sXn1DRgw9ZKcDdrQthZaUhn-rxAMIwuIc4d7idSpY5okgc';
}
