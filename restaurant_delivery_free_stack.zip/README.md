# Restaurant Delivery (Free Stack) – Firebase Auth+FCM + Supabase DB + OSM Maps

هذا قالب جاهز **بدون Google Maps وبدون Firebase Storage**:
- Firebase: تسجيل دخول + إشعارات (FCM)
- Supabase: قاعدة البيانات + Realtime للتتبع
- خرائط مجانية: OpenStreetMap عبر flutter_map

## تشغيل سريع داخل Codespaces

1) فك الضغط داخل الريبو
2) نفّذ سكريبت الإعداد (يعمل Flutter install + إنشاء مشروع + نسخ الكود):
```bash
chmod +x scripts/setup.sh
bash scripts/setup.sh
```

3) تشغيل الويب على منفذ 8080:
```bash
cd restaurant_app
flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8080
```

4) بناء APK:
```bash
cd restaurant_app
flutter build apk --release
```

## ملاحظات مهمة
- مفاتيح Firebase/Supabase موجودة داخل `restaurant_app/lib/config/` كما طلبت.
- إذا بدك أمان أعلى لاحقاً: انقلهم إلى `.env` واستعمل flutter_dotenv.
